/*
 * Copyright (c) 2014, The Linux Foundation. All rights reserved.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _DT_BINDINGS_CLK_LCC_MSM8960_H
#define _DT_BINDINGS_CLK_LCC_MSM8960_H

#define PLL4				0
#define MI2S_OSR_SRC			1
#define MI2S_OSR_CLK			2
#define MI2S_DIV_CLK			3
#define MI2S_BIT_DIV_CLK		4
#define MI2S_BIT_CLK			5
#define PCM_SRC				6
#define PCM_CLK_OUT			7
#define PCM_CLK				8
#define SLIMBUS_SRC			9
#define AUDIO_SLIMBUS_CLK		10
#define SPS_SLIMBUS_CLK			11
#define CODEC_I2S_MIC_OSR_SRC		12
#define CODEC_I2S_MIC_OSR_CLK		13
#define CODEC_I2S_MIC_DIV_CLK		14
#define CODEC_I2S_MIC_BIT_DIV_CLK	15
#define CODEC_I2S_MIC_BIT_CLK		16
#define SPARE_I2S_MIC_OSR_SRC		17
#define SPARE_I2S_MIC_OSR_CLK		18
#define SPARE_I2S_MIC_DIV_CLK		19
#define SPARE_I2S_MIC_BIT_DIV_CLK	20
#define SPARE_I2S_MIC_BIT_CLK		21
#define CODEC_I2S_SPKR_OSR_SRC		22
#define CODEC_I2S_SPKR_OSR_CLK		23
#define CODEC_I2S_SPKR_DIV_CLK		24
#define CODEC_I2S_SPKR_BIT_DIV_CLK	25
#define CODEC_I2S_SPKR_BIT_CLK		26
#define SPARE_I2S_SPKR_OSR_SRC		27
#define SPARE_I2S_SPKR_OSR_CLK		28
#define SPARE_I2S_SPKR_DIV_CLK		29
#define SPARE_I2S_SPKR_BIT_DIV_CLK	30
#define SPARE_I2S_SPKR_BIT_CLK		31

#endif
